""" Synse Server gRPC internal plugin API.
"""

from . import synse_pb2 as api
from . import synse_pb2_grpc as grpc

"""Synse gRPC API for plugin communication."""

__title__ = 'synse_grpc'
__version__ = '3.0.0-alpha.2'
__description__ = 'The Synse gRPC API for plugin communication.'
__author__ = 'Vapor IO'
__author_email__ = 'vapor@vapor.io'
__url__ = 'https://github.com/vapor-ware/synse-server-grpc'
__license__ = 'GNU General Public License v3.0'
